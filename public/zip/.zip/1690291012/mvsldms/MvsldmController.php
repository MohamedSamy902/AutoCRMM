<?php

namespace App\Http\Controllers;

use App\Models\Mvsldm;
use Illuminate\Http\Request;
use App\Http\Requests\mvsldms\StoreMvsldmRequest;
use App\Http\Requests\mvsldms\UpdateMvsldmRequest;

class MvsldmController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $mvsldms = Mvsldm::get();
        return view('admin.mvsldms.index', \compact('mvsldms'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('admin.mvsldms.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \App\Http\Requests\StoremvsldmRequest  $request
     * @return \Illuminate\Http\Response
     */
    public function store(StoreMvsldmRequest $request)
    {
        try {

            // Cereat Request
            $mvsldm = Mvsldm::create($request->validated());
            // Check Done Or Fil
            if ($mvsldm) {
                // Redirect Success Masseg
                return redirect()->route('mvsldms.create')->with(['success' => 'تم حفط القسم بنجاح']);
            } else {
                // Return Error Massege
                return redirect()->route('mvsldms.index')->with(['error' => 'يرجي المحاوله مره اخري']);
            }
        } catch (\Exception $ex) {
            // Massege Error
            return redirect()->route('mvsldms.index')->with(['error' => 'يرجي المحاوله مره اخري']);
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\mvsldm  $mvsldm
     * @return \Illuminate\Http\Response
     */
    public function show(Mvsldm $mvsldm)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\mvsldm  $mvsldm
     * @return \Illuminate\Http\Response
     */
    public function edit(Mvsldm $mvsldm)
    {
        $mvsldm = Mvsldm::findOrFail($mvsldm->id);
        return view('admin.mvsldms.edit', \compact('mvsldm'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \App\Http\Requests\UpdatemvsldmRequest  $request
     * @param  \App\Models\mvsldm  $mvsldm
     * @return \Illuminate\Http\Response
     */
    public function update(UpdateMvsldmRequest $request, Mvsldm $mvsldm)
    {
        $mvsldm = Mvsldm::find($mvsldm->id);
        if ($mvsldm) {
            $data = $request->all();
            $status = $mvsldm->fill($data)->save();
            if ($status) {
                return redirect()->route('mvsldms.index')->with(['success' => 'تم تعديل القسم بنجاح']);
            } else {
                return redirect()->route('mvsldms.index')->with(['error' => 'يرجي المحاوله مره اخري']);
            }
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\mvsldm  $mvsldm
     * @return \Illuminate\Http\Response
     */
    public function destroy(Mvsldm $mvsldm)
    {
        try {
            $mvsldm = Mvsldm::findOrFail($mvsldm->id);
            $mvsldm->delete();
            return redirect()->route('mvsldms.index')->with(['success' => 'تم الحذف بنجاح']);
        } catch (\Exception $ex) {
            return redirect()->route('mvsldms.index')->with(['error' => 'يرجي المحاوله مره اخري']);
        }
    }
}
