<?php

namespace App\Http\Controllers;

use App\Models\Sfvs;
use Illuminate\Http\Request;
use App\Http\Requests\sfvs\StoreSfvsRequest;
use App\Http\Requests\sfvs\UpdateSfvsRequest;

class SfvsController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $sfvs = Sfvs::get();
        return view('admin.sfvs.index', \compact('sfvs'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('admin.sfvs.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \App\Http\Requests\StoresfvsRequest  $request
     * @return \Illuminate\Http\Response
     */
    public function store(StoreSfvsRequest $request)
    {
        try {

            // Cereat Request
            $sfvs = Sfvs::create($request->validated());
            // Check Done Or Fil
            if ($sfvs) {
                // Redirect Success Masseg
                return redirect()->route('sfvs.create')->with(['success' => 'تم حفط القسم بنجاح']);
            } else {
                // Return Error Massege
                return redirect()->route('sfvs.index')->with(['error' => 'يرجي المحاوله مره اخري']);
            }
        } catch (\Exception $ex) {
            // Massege Error
            return redirect()->route('sfvs.index')->with(['error' => 'يرجي المحاوله مره اخري']);
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\sfvs  $sfvs
     * @return \Illuminate\Http\Response
     */
    public function show(Sfvs $sfvs)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\sfvs  $sfvs
     * @return \Illuminate\Http\Response
     */
    public function edit(Sfvs $sfvs)
    {
        $sfvs = Sfvs::findOrFail($sfvs->id);
        return view('admin.sfvs.edit', \compact('sfvs'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \App\Http\Requests\UpdatesfvsRequest  $request
     * @param  \App\Models\sfvs  $sfvs
     * @return \Illuminate\Http\Response
     */
    public function update(UpdateSfvsRequest $request, Sfvs $sfvs)
    {
        $sfvs = Sfvs::find($sfvs->id);
        if ($sfvs) {
            $data = $request->all();
            $status = $sfvs->fill($data)->save();
            if ($status) {
                return redirect()->route('sfvs.index')->with(['success' => 'تم تعديل القسم بنجاح']);
            } else {
                return redirect()->route('sfvs.index')->with(['error' => 'يرجي المحاوله مره اخري']);
            }
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\sfvs  $sfvs
     * @return \Illuminate\Http\Response
     */
    public function destroy(Sfvs $sfvs)
    {
        try {
            $sfvs = Sfvs::findOrFail($sfvs->id);
            $sfvs->delete();
            return redirect()->route('sfvs.index')->with(['success' => 'تم الحذف بنجاح']);
        } catch (\Exception $ex) {
            return redirect()->route('sfvs.index')->with(['error' => 'يرجي المحاوله مره اخري']);
        }
    }
}
