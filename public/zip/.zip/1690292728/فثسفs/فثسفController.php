<?php

namespace App\Http\Controllers;

use App\Models\فثسف;
use Illuminate\Http\Request;
use App\Http\Requests\فثسفs\StoreفثسفRequest;
use App\Http\Requests\فثسفs\UpdateفثسفRequest;

class فثسفController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $فثسفs = فثسف::get();
        return view('admin.فثسفs.index', \compact('فثسفs'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('admin.فثسفs.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \App\Http\Requests\StoreفثسفRequest  $request
     * @return \Illuminate\Http\Response
     */
    public function store(StoreفثسفRequest $request)
    {
        try {

            // Cereat Request
            $فثسف = فثسف::create($request->validated());
            // Check Done Or Fil
            if ($فثسف) {
                // Redirect Success Masseg
                return redirect()->route('فثسفs.create')->with(['success' => 'تم حفط القسم بنجاح']);
            } else {
                // Return Error Massege
                return redirect()->route('فثسفs.index')->with(['error' => 'يرجي المحاوله مره اخري']);
            }
        } catch (\Exception $ex) {
            // Massege Error
            return redirect()->route('فثسفs.index')->with(['error' => 'يرجي المحاوله مره اخري']);
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\فثسف  $فثسف
     * @return \Illuminate\Http\Response
     */
    public function show(فثسف $فثسف)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\فثسف  $فثسف
     * @return \Illuminate\Http\Response
     */
    public function edit(فثسف $فثسف)
    {
        $فثسف = فثسف::findOrFail($فثسف->id);
        return view('admin.فثسفs.edit', \compact('فثسف'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \App\Http\Requests\UpdateفثسفRequest  $request
     * @param  \App\Models\فثسف  $فثسف
     * @return \Illuminate\Http\Response
     */
    public function update(UpdateفثسفRequest $request, فثسف $فثسف)
    {
        $فثسف = فثسف::find($فثسف->id);
        if ($فثسف) {
            $data = $request->all();
            $status = $فثسف->fill($data)->save();
            if ($status) {
                return redirect()->route('فثسفs.index')->with(['success' => 'تم تعديل القسم بنجاح']);
            } else {
                return redirect()->route('فثسفs.index')->with(['error' => 'يرجي المحاوله مره اخري']);
            }
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\فثسف  $فثسف
     * @return \Illuminate\Http\Response
     */
    public function destroy(فثسف $فثسف)
    {
        try {
            $فثسف = فثسف::findOrFail($فثسف->id);
            $فثسف->delete();
            return redirect()->route('فثسفs.index')->with(['success' => 'تم الحذف بنجاح']);
        } catch (\Exception $ex) {
            return redirect()->route('فثسفs.index')->with(['error' => 'يرجي المحاوله مره اخري']);
        }
    }
}
