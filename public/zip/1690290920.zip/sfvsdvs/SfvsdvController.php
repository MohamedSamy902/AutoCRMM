<?php

namespace App\Http\Controllers;

use App\Models\Sfvsdv;
use Illuminate\Http\Request;
use App\Http\Requests\sfvsdvs\StoreSfvsdvRequest;
use App\Http\Requests\sfvsdvs\UpdateSfvsdvRequest;

class SfvsdvController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $sfvsdvs = Sfvsdv::get();
        return view('admin.sfvsdvs.index', \compact('sfvsdvs'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('admin.sfvsdvs.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \App\Http\Requests\StoresfvsdvRequest  $request
     * @return \Illuminate\Http\Response
     */
    public function store(StoreSfvsdvRequest $request)
    {
        try {

            // Cereat Request
            $sfvsdv = Sfvsdv::create($request->validated());
            // Check Done Or Fil
            if ($sfvsdv) {
                // Redirect Success Masseg
                return redirect()->route('sfvsdvs.create')->with(['success' => 'تم حفط القسم بنجاح']);
            } else {
                // Return Error Massege
                return redirect()->route('sfvsdvs.index')->with(['error' => 'يرجي المحاوله مره اخري']);
            }
        } catch (\Exception $ex) {
            // Massege Error
            return redirect()->route('sfvsdvs.index')->with(['error' => 'يرجي المحاوله مره اخري']);
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\sfvsdv  $sfvsdv
     * @return \Illuminate\Http\Response
     */
    public function show(Sfvsdv $sfvsdv)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\sfvsdv  $sfvsdv
     * @return \Illuminate\Http\Response
     */
    public function edit(Sfvsdv $sfvsdv)
    {
        $sfvsdv = Sfvsdv::findOrFail($sfvsdv->id);
        return view('admin.sfvsdvs.edit', \compact('sfvsdv'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \App\Http\Requests\UpdatesfvsdvRequest  $request
     * @param  \App\Models\sfvsdv  $sfvsdv
     * @return \Illuminate\Http\Response
     */
    public function update(UpdateSfvsdvRequest $request, Sfvsdv $sfvsdv)
    {
        $sfvsdv = Sfvsdv::find($sfvsdv->id);
        if ($sfvsdv) {
            $data = $request->all();
            $status = $sfvsdv->fill($data)->save();
            if ($status) {
                return redirect()->route('sfvsdvs.index')->with(['success' => 'تم تعديل القسم بنجاح']);
            } else {
                return redirect()->route('sfvsdvs.index')->with(['error' => 'يرجي المحاوله مره اخري']);
            }
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\sfvsdv  $sfvsdv
     * @return \Illuminate\Http\Response
     */
    public function destroy(Sfvsdv $sfvsdv)
    {
        try {
            $sfvsdv = Sfvsdv::findOrFail($sfvsdv->id);
            $sfvsdv->delete();
            return redirect()->route('sfvsdvs.index')->with(['success' => 'تم الحذف بنجاح']);
        } catch (\Exception $ex) {
            return redirect()->route('sfvsdvs.index')->with(['error' => 'يرجي المحاوله مره اخري']);
        }
    }
}
