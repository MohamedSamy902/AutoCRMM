<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Sfvs extends Model
{
    use HasFactory;

    protected $fillable = [
        'nfkldf',
    ];


}
