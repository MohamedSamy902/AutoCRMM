<?php

namespace App\Http\Controllers;

use App\Models\Mohamed;
use Illuminate\Http\Request;
use App\Http\Requests\mohameds\StoreMohamedRequest;
use App\Http\Requests\mohameds\UpdateMohamedRequest;

class MohamedController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $mohameds = Mohamed::get();
        return view('admin.mohameds.index', \compact('mohameds'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('admin.mohameds.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \App\Http\Requests\StoremohamedRequest  $request
     * @return \Illuminate\Http\Response
     */
    public function store(StoreMohamedRequest $request)
    {
        try {

            // Cereat Request
            $mohamed = Mohamed::create($request->validated());
            // Check Done Or Fil
            if ($mohamed) {
                // Redirect Success Masseg
                return redirect()->route('mohameds.create')->with(['success' => 'تم حفط القسم بنجاح']);
            } else {
                // Return Error Massege
                return redirect()->route('mohameds.index')->with(['error' => 'يرجي المحاوله مره اخري']);
            }
        } catch (\Exception $ex) {
            // Massege Error
            return redirect()->route('mohameds.index')->with(['error' => 'يرجي المحاوله مره اخري']);
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\mohamed  $mohamed
     * @return \Illuminate\Http\Response
     */
    public function show(Mohamed $mohamed)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\mohamed  $mohamed
     * @return \Illuminate\Http\Response
     */
    public function edit(Mohamed $mohamed)
    {
        $mohamed = Mohamed::findOrFail($mohamed->id);
        return view('admin.mohameds.edit', \compact('mohamed'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \App\Http\Requests\UpdatemohamedRequest  $request
     * @param  \App\Models\mohamed  $mohamed
     * @return \Illuminate\Http\Response
     */
    public function update(UpdateMohamedRequest $request, Mohamed $mohamed)
    {
        $mohamed = Mohamed::find($mohamed->id);
        if ($mohamed) {
            $data = $request->all();
            $status = $mohamed->fill($data)->save();
            if ($status) {
                return redirect()->route('mohameds.index')->with(['success' => 'تم تعديل القسم بنجاح']);
            } else {
                return redirect()->route('mohameds.index')->with(['error' => 'يرجي المحاوله مره اخري']);
            }
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\mohamed  $mohamed
     * @return \Illuminate\Http\Response
     */
    public function destroy(Mohamed $mohamed)
    {
        try {
            $mohamed = Mohamed::findOrFail($mohamed->id);
            $mohamed->delete();
            return redirect()->route('mohameds.index')->with(['success' => 'تم الحذف بنجاح']);
        } catch (\Exception $ex) {
            return redirect()->route('mohameds.index')->with(['error' => 'يرجي المحاوله مره اخري']);
        }
    }
}
