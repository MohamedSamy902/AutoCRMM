<?php

namespace App\Http\Controllers;

use App\Models\Test;
use Illuminate\Http\Request;
use App\Http\Requests\tests\StoreTestRequest;
use App\Http\Requests\tests\UpdateTestRequest;

class TestController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $tests = Test::get();
        return view('admin.tests.index', \compact('tests'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('admin.tests.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \App\Http\Requests\StoretestRequest  $request
     * @return \Illuminate\Http\Response
     */
    public function store(StoreTestRequest $request)
    {
        try {

            // Cereat Request
            $test = Test::create($request->validated());
            // Check Done Or Fil
            if ($test) {
                // Redirect Success Masseg
                return redirect()->route('tests.create')->with(['success' => 'تم حفط القسم بنجاح']);
            } else {
                // Return Error Massege
                return redirect()->route('tests.index')->with(['error' => 'يرجي المحاوله مره اخري']);
            }
        } catch (\Exception $ex) {
            // Massege Error
            return redirect()->route('tests.index')->with(['error' => 'يرجي المحاوله مره اخري']);
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\test  $test
     * @return \Illuminate\Http\Response
     */
    public function show(Test $test)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\test  $test
     * @return \Illuminate\Http\Response
     */
    public function edit(Test $test)
    {
        $test = Test::findOrFail($test->id);
        return view('admin.tests.edit', \compact('test'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \App\Http\Requests\UpdatetestRequest  $request
     * @param  \App\Models\test  $test
     * @return \Illuminate\Http\Response
     */
    public function update(UpdateTestRequest $request, Test $test)
    {
        $test = Test::find($test->id);
        if ($test) {
            $data = $request->all();
            $status = $test->fill($data)->save();
            if ($status) {
                return redirect()->route('tests.index')->with(['success' => 'تم تعديل القسم بنجاح']);
            } else {
                return redirect()->route('tests.index')->with(['error' => 'يرجي المحاوله مره اخري']);
            }
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\test  $test
     * @return \Illuminate\Http\Response
     */
    public function destroy(Test $test)
    {
        try {
            $test = Test::findOrFail($test->id);
            $test->delete();
            return redirect()->route('tests.index')->with(['success' => 'تم الحذف بنجاح']);
        } catch (\Exception $ex) {
            return redirect()->route('tests.index')->with(['error' => 'يرجي المحاوله مره اخري']);
        }
    }
}
